#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

int partition(int *arr, int low, int high)
{
    int pivot = arr[high];
    int i = low - 1;
    for (int j = low; j < high; j++)
    {
        if (arr[j] < pivot)
        {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return i + 1;
}

void quickSort(int *arr, int low, int high)
{
    if (low < high)
    {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

void printMatrix(int **matrix, int m, int n)
{
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

int main()
{
    int m, n;
    printf("Enter the number of rows and columns: ");
    scanf("%d %d", &m, &n);
    int **matrix = (int **)malloc(m * sizeof(int *));
    for (int i = 0; i < m; i++)
    {
        matrix[i] = (int *)malloc(n * sizeof(int));
    }
    srand(time(0));
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            matrix[i][j] = rand() % 100;
        }
    }
    printf("\nMatrix:\n");
    printMatrix(matrix, m, n);
    int studentID;
    printf("\nEnter your student ID: ");
    scanf("%d", &studentID);
    int lastDigit = studentID % 10;
    int sum = 0;
    if (lastDigit == 0 || lastDigit == 1 || lastDigit == 2)
    {
        #pragma omp parallel for num_threads(n)
        for (int i = 0; i < n; i++)
        {
            quickSort(matrix[i], 0, m - 1);
            for (int j = 0; j < m; j++)
            {
                sum += matrix[j][i];
            }
        }
    }
    else if (lastDigit == 3 || lastDigit == 4 || lastDigit == 5)
    {
        #pragma omp parallel for num_threads(n)
        for (int i = 0; i < n; i++)
        {
            quickSort(matrix[i], 0, m - 1);
            for (int j = 0; j < m; j++)
            {
                sum += matrix[j][i];
            }
        }
    }
    else if (lastDigit == 6 || lastDigit == 7)
    {
        #pragma omp parallel for num_threads(m)
        for (int i = 0; i < m; i++)
        {
            quickSort(matrix[i], 0, n - 1);
            for (int j = 0; j < n; j++)
            {
                sum += matrix[i][j];
            }
        }
    }
    else if (lastDigit == 8 || lastDigit == 9)
    {
        #pragma omp parallel for num_threads(m)
        for (int i = 0; i < m; i++)
        {
            quickSort(matrix[i], 0, n - 1);
            for (int j = 0; j < n; j++)
            {
                sum += matrix[i][j];
            }
        }
    }
    printf("\nSorted Matrix:\n");
    printMatrix(matrix, m, n);
    printf("\nSum of all elements: %d\n", sum);
    return 0;
}

/*

The above code is a C program that generates a random matrix of size m x n and performs quicksort on its rows or
columns depending on the last digit of the user's input student ID. The sum of all elements of the matrix is also calculated and printed.

The program starts by including the required header files, which are stdio.h, stdlib.h, omp.h, and time.h. 
Then, the function swap() is defined to swap two integers, and the function partition() is defined to partition an array using the last element as the pivot.

The function quickSort() is defined to perform quicksort on an array. It uses partition() to partition the array and recursively sorts the subarrays.

The function printMatrix() is defined to print the elements of a matrix.

In the main function, the user is prompted to enter the number of rows and columns of the matrix. The matrix is
then dynamically allocated using malloc(), and each element is initialized with a random integer between 0 and 99 using rand().

The user is then prompted to enter their student ID, and the last digit of the ID is computed using the modulo operator.
Depending on the last digit, quicksort is performed on the rows or columns of the matrix using OpenMP parallelization.

If the last digit is 0, 1, or 2, quicksort is performed on each column of the matrix using OpenMP parallelization.
If the last digit is 3, 4, or 5, quicksort is performed on each column of the matrix using OpenMP parallelization.
If the last digit is 6 or 7, quicksort is performed on each row of the matrix using OpenMP parallelization.
If the last digit is 8 or 9, quicksort is performed on each row of the matrix using OpenMP parallelization.

Finally, the sorted matrix and the sum of all elements are printed using the printMatrix() function and printf()
function, respectively.

In summary, the program generates a random matrix, performs quicksort on its rows or columns using OpenMP parallelization,
and calculates the sum of all elements. The specific operation to be performed (sorting rows or columns) is determined by
the last digit of the user's input student ID.
*/